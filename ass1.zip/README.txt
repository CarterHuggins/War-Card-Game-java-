﻿Carter Huggins
Project: Assignment 1


Assignment 1 is an implementation of the popular card game War. 


Files Included:
* WarGame.java
* SQueue.java
* Shuffable.java
* Card.java
* QueueInterface.java
* Ass1Test.java
* CardQueueTest.java




Compile the Code = javac *.java
Execute the WarGame = java WarGame




Developer Notes:
*  I didn’t import any extra libraries or anything special, I based my WarGame on multiple loops that determine who wins each round and then what actions occur based on who won.
* I made sure to keep the circular array in mind throughout the project, implementing it in the SQueue.java file. This made it easier to efficiently manage the queue elements when it came to enqueueing or dequeueing a card.
* I set the max rounds to 50, and tracked each player's wins. You will see that whenever the game executes
* To determine when a war happens, I made an if-else statement based upon the comparison of each player’s hand. If there’s an else statement, then there’s a War.




If you have any other questions about the code, please e-mail me at cwh42@pitt.edu!